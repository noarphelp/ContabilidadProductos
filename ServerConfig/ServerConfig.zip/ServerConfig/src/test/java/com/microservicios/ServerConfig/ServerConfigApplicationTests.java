package com.microservicios.ServerConfig;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerConfigApplicationTests {

	@Test
	void contextLoads() {
	}

}
