package com.Contabilidad.EnvioMails;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnvioMailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(EnvioMailsApplication.class, args);
	}

}
