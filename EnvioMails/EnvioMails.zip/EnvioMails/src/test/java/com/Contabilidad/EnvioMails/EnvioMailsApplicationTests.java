package com.Contabilidad.EnvioMails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnvioMailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
